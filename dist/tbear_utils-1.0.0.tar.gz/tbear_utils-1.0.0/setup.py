from setuptools import setup, find_packages

setup(
    name='tbear_utils',
    version='1.0.0',
    packages=find_packages(),
    install_requires=[
    # List any dependencies your project requires
],
)